#!/bin/bash

source lib/utils.sh
source lib/enum.sh

TARGET=$1

if [ -z "$TARGET" ]; then
    echo "Usage: ./recon.sh target.com"
    exit 1
fi

log "[+] Starting reconnaissance for $TARGET"

check_dependencies

init_project "$TARGET"

run_enumeration "$TARGET"

clean_results "$TARGET"

log "[+] Recon completed."
log "[+] Raw results    : output/$TARGET/raw.txt"
log "[+] Unique results : output/$TARGET/unique.txt"
