#!/bin/bash

log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

check_dependencies() {

    tools=(
        subfinder
        assetfinder
        curl
        jq
    )

    log "[*] Checking dependencies..."

    for tool in "${tools[@]}"
    do
        if command -v "$tool" &>/dev/null
        then
            log "[+] $tool found"
        else
            log "[!] $tool not installed"
            exit 1
        fi
    done

}

init_project() {

    mkdir -p output/$1
    mkdir -p logs

    > output/$1/raw.txt

}

clean_results() {

    cat output/$1/raw.txt \
    | sed 's|http://||' \
    | sed 's|https://||' \
    | sed 's|/.*||' \
    | sed 's/\*\.//' \
    | grep "$1" \
    | sort -u \
    > output/$1/unique.txt

}
