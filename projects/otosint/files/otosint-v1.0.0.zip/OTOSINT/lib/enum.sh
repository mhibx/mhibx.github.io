#!/bin/bash

run_enumeration() {

    TARGET=$1

    #
    # Subfinder
    #
    log "[*] Running Subfinder..."

    subfinder -d "$TARGET" -silent \
        >> output/$TARGET/raw.txt \
        2>/dev/null

    #
    # Assetfinder
    #
    log "[*] Running Assetfinder..."

    assetfinder --subs-only "$TARGET" \
        >> output/$TARGET/raw.txt \
        2>/dev/null

    #
    # crt.sh
    #
    log "[*] Querying crt.sh..."

    response=$(curl \
        --connect-timeout 10 \
        --max-time 30 \
        -s \
        "https://crt.sh/?q=%25.$TARGET&output=json")

    if [ -n "$response" ]; then

        echo "$response" \
            | jq -r '.[].name_value' 2>/dev/null \
            | tr '\r' '\n' \
            | sed 's/\*\.//' \
            >> output/$TARGET/raw.txt

        log "[+] crt.sh completed."

    else

        log "[!] crt.sh returned empty response."

    fi

}
